/* Thandi's Hair & Beauty Studio - Part 3 interactivity
   Features: mobile nav, scroll-reveal animations, services (dynamic content +
   search/filter/sort), FAQ accordion, gallery lightbox, form validation + AJAX */
(() => {
  'use strict';
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];
}
  /* ---------- Mobile navigation + active link ---------- */
  const toggle = $('.nav-toggle');
  const links = $('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', () => {
      const open = links.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(open));
    });
  }
  const here = location.pathname.split('/').pop() || 'index.html';
  $$('.nav-links a:not(.nav-cta)').forEach(a => {
    if (a.getAttribute('href') === here) {
      a.classList.add('active');
      a.setAttribute('aria-current', 'page');
    }
  });

  /* ---------- Scroll-reveal animation (CSS transition + IntersectionObserver) ---------- */
  const observer = 'IntersectionObserver' in window
    ? new IntersectionObserver(entries => entries.forEach(e => {
        if (e.isIntersecting) { e.target.classList.add('visible'); observer.unobserve(e.target); }
      }), { threshold: 0.12 })
    : null;
  const reveal = els => els.forEach(el => {
    el.classList.add('reveal');
    observer ? observer.observe(el) : el.classList.add('visible');
  });
  reveal($$('[data-reveal]'));

  /* ---------- Accordion (FAQ) ---------- */
  $$('.accordion-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const panel = document.getElementById(btn.getAttribute('aria-controls'));
      const open = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', String(!open));
      panel.classList.toggle('open', !open);
    });
  });

  /* ---------- Services: dynamic content + search / filter / sort ---------- */
  const grid = $('#services-grid');
  if (grid) {
    const U = id => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=600&q=80`;
    const SERVICES = [
      { id: 'facial',  name: 'Facial Treatments', category: 'Face', price: 350, img: U('photo-1516975080664-ed2fc6a32937'),
        desc: 'Deep cleansing, hydration, and rejuvenation facials tailored to your skin type for a radiant glow.' },
      { id: 'makeup',  name: 'Makeup Artistry',   category: 'Face', price: 500, img: U('photo-1522337360788-8b13dee7a37e'),
        desc: 'Bridal, special occasion, and everyday glam makeup using premium cruelty-free products.' },
      { id: 'nails',   name: 'Nail Care',         category: 'Nails', price: 180, img: U('photo-1604654894610-df63bc536371'),
        desc: 'Manicures, pedicures, gel overlays, and nail art that express your unique style.' },
      { id: 'lash',    name: 'Lash & Brow',       category: 'Face', price: 250, img: U('photo-1560869713-bf09a5df6d2b'),
        desc: 'Eyelash extensions, lash lifts, brow shaping, and tinting to frame your face perfectly.' },
      { id: 'hair',    name: 'Hair Styling',      category: 'Hair', price: 300, img: U('photo-1519823551278-64ac92734fb1'),
        desc: 'Professional styling, treatments, and braiding for all hair types and textures.' },
      { id: 'massage', name: 'Massage Therapy',   category: 'Body', price: 400, img: U('photo-1544161515-4ab6ce6db874'),
        desc: 'Relaxing Swedish and deep tissue massages to melt away stress and tension.' }
    ];

    const search = $('#service-search');
    const category = $('#service-category');
    const sort = $('#service-sort');
    const count = $('#service-count');

    [...new Set(SERVICES.map(s => s.category))].sort().forEach(c => {
      category.append(new Option(c, c));
    });

    const render = () => {
      const q = search.value.trim().toLowerCase();
      let list = SERVICES.filter(s =>
        (!category.value || s.category === category.value) &&
        (!q || `${s.name} ${s.desc} ${s.category}`.toLowerCase().includes(q)));
      const by = {
        'name': (a, b) => a.name.localeCompare(b.name),
        'price-asc': (a, b) => a.price - b.price,
        'price-desc': (a, b) => b.price - a.price
      }[sort.value];
      list = list.sort(by);

      grid.replaceChildren();
      list.forEach(s => {
        const card = document.createElement('article');
        card.className = 'service-card';
        card.innerHTML = `
          <img class="service-img" src="${s.img}" alt="${s.name} at Thandi's Hair &amp; Beauty Studio" loading="lazy" width="600" height="400">
          <div class="service-info">
            <span class="tag">${s.category}</span>
            <h3>${s.name}</h3>
            <p>${s.desc}</p>
            <span class="price">From R${s.price}</span>
            <a class="btn btn-small" href="contact.html?service=${s.id}">Book this service</a>
          </div>`;
        grid.append(card);
        reveal([card]);
      });
      count.textContent = list.length
        ? `Showing ${list.length} of ${SERVICES.length} services`
        : 'No services match your search. Try a different word or clear the filter.';
    };
    [search, category, sort].forEach(el => el.addEventListener('input', render));
    render();
  }

  /* ---------- Gallery lightbox (native <dialog>) ---------- */
  const items = $$('.gallery-item');
  if (items.length && 'HTMLDialogElement' in window) {
    const dlg = document.createElement('dialog');
    dlg.className = 'lightbox';
    dlg.setAttribute('aria-label', 'Image viewer');
    dlg.innerHTML = `
      <button class="lb-btn lb-close" aria-label="Close image viewer">&times;</button>
      <button class="lb-btn lb-prev" aria-label="Previous image">&#8249;</button>
      <figure><img alt=""><figcaption></figcaption></figure>
      <button class="lb-btn lb-next" aria-label="Next image">&#8250;</button>`;
    document.body.append(dlg);
    const img = $('img', dlg), cap = $('figcaption', dlg);
    let idx = 0;
    const show = i => {
      idx = (i + items.length) % items.length;
      const a = items[idx];
      img.src = a.getAttribute('href');
      img.alt = $('img', a).alt;
      cap.textContent = `${$('h4', a).textContent} - ${$('p', a).textContent}`;
    };
    items.forEach((a, i) => a.addEventListener('click', e => {
      e.preventDefault(); show(i); dlg.showModal();
    }));
    $('.lb-close', dlg).addEventListener('click', () => dlg.close());
    $('.lb-prev', dlg).addEventListener('click', () => show(idx - 1));
    $('.lb-next', dlg).addEventListener('click', () => show(idx + 1));
    dlg.addEventListener('click', e => { if (e.target === dlg) dlg.close(); });
    dlg.addEventListener('keydown', e => {
      if (e.key === 'ArrowRight') show(idx + 1);
      if (e.key === 'ArrowLeft') show(idx - 1);
    });
  }

  /* ---------- Contact page: Leaflet map ---------- */
  const mapEl = $('#map');
  if (mapEl && window.L) {
    // Approximate position of Diepsloot Crossing - confirm exact coordinates before publishing.
    const pos = [-25.9318, 28.0108];
    const map = L.map(mapEl).setView(pos, 15);
    
      maxZoom: 19,
      attribution; '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }.addTo(map);
    L.marker(pos).addTo(map)
      .bindPopup("<strong>Thandi's Hair &amp; Beauty Studio</strong><br>Diepsloot Crossing, Diepsloot")
      .openPopup();
  

  /* ---------- Contact form: validation + AJAX submission ---------- */
  const form = $('#contact-form');
  if (form) {
    const status = $('#form-status');
    const rules = {
      name: v => v.trim().length >= 2 || 'Please enter your full name (at least 2 characters).',
      email: v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) || 'Please enter a valid email address, e.g. name@example.com.',
      phone: v => /^(\+27|0)[1-9]\d{8}$/.test(v.replace(/[\s-]/g, '')) || 'Enter a valid South African number, e.g. 072 123 4567.',
      service: v => v !== '' || 'Please choose a service.',
      date: v => {
        if (!v) return true; // optional
        const d = new Date(v + 'T00:00:00');
        const today = new Date(); today.setHours(0, 0, 0, 0);
        if (d < today) return 'Please choose a date that is today or later.';
        if (d.getDay() === 0) return 'We are closed on Sundays - please pick another day.';
        return true;
      },
      message: v => v.trim().length >= 10 || 'Please tell us a little more (at least 10 characters).'
    };
 function upDateTime(){
                const now=new Date();
                const options={
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                }
    // Date picker: no past dates
    const dateInput = $('#date');
    dateInput.min = new Date().toISOString().split('T')[0];

    // Pre-select service from ?service=hair
    const wanted = new URLSearchParams(location.search).get('service');
    if (wanted && $(`#service option[value="${wanted}"]`)) $('#service').value = wanted;

    const setError = (field, msg) => {
      const err = $(`#${field.id}-error`);
      err.textContent = msg || '';
      field.setAttribute('aria-invalid', msg ? 'true' : 'false');
      field.classList.toggle('invalid', Boolean(msg));
    };
    const check = field => {
      const result = rules[field.name](field.value);
      setError(field, result === true ? '' : result);
      return result === true;
    };
    Object.keys(rules).forEach(n => {
      const f = form.elements[n];
      f.addEventListener('blur', () => check(f));
      f.addEventListener('input', () => { if (f.classList.contains('invalid')) check(f); });
    });

    form.addEventListener('submit', async e => {
      e.preventDefault();
      status.className = 'form-status';
      status.textContent = '';

      const results = Object.keys(rules).map(n => check(form.elements[n]));
      const consent = form.elements.consent;
      const consentOk = consent.checked;
      $('#consent-error').textContent = consentOk ? '' : 'Please tick the box so we can contact you about your enquiry.';
      if (results.includes(false) || !consentOk) {
        const first = $('.invalid, #consent:not(:checked)', form);
        status.classList.add('error');
        status.textContent = 'Please fix the highlighted fields and try again.';
        first && first.focus();
        return;
      }

      const btn = $('button[type="submit"]', form);
      btn.disabled = true; btn.textContent = 'Sending...';
      const demo = form.action.includes('your-form-id');
      try {
        if (demo) {
          await new Promise(r => setTimeout(r, 800));
          console.warn('Demo mode: set the form action to your Formspree endpoint to receive messages.');
        } else {
          const res = await fetch(form.action, {
            method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' }
          });
          if (!res.ok) throw new Error('Request failed: ' + res.status);
        }
        status.classList.add('success');
        status.textContent = `Thank you, ${form.elements.name.value.trim().split(' ')[0]}! Your message has been sent and we will reply soon.` +
          (demo ? ' (Demo mode - connect a form service to receive messages.)' : '');
        form.reset();
        $$('.invalid', form).forEach(f => setError(f, ''));
      } catch (err) {
        status.classList.add('error');
        status.textContent = 'Sorry, something went wrong sending your message. Please try again or WhatsApp us on +27 72 123 4567.';
      } finally {
        btn.disabled = false; btn.textContent = 'Send Message';
        status.focus();
      }
    });
  }
)();
